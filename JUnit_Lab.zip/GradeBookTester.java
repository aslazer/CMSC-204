import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTester {

	GradeBook book1, book2;
	
	@BeforeEach
	void setUp() throws Exception {
		
		book1 = new GradeBook(5);
		book2 = new GradeBook(5);
		
		book1.addScore(4);
		book1.addScore(2);
		book1.addScore(3);
		
		book2.addScore(98);
		book2.addScore(45);
		book2.addScore(100);
		book2.addScore(99);
	}

	@AfterEach
	void tearDown() throws Exception {
		
		book1 = null;
		book2 = null;
	}

	@Test
	void testAddScore() {
		
		assertTrue(book1.toString().equals("4.0 2.0 3.0 0.0 0.0 "));
		assertTrue(book2.toString().equals("98.0 45.0 100.0 99.0 0.0 "));
		
		assertEquals(book1.getScoreSize(), 3);
		assertEquals(book2.getScoreSize(), 4);
	}

	@Test
	void testSum() {
		
		assertEquals(book1.sum(), 9);
		assertEquals(book2.sum(), 342);
	}

	@Test
	void testMinimum() {
		
		assertEquals(book1.minimum(), 2.0);
		assertEquals(book2.minimum(), 45.0);
	}

	@Test
	void testFinalScore() {
		
		assertEquals(book1.finalScore(), 7.0);
		assertEquals(book2.finalScore(), 297.0);
	}

}
